import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

Message processData(Message message) {
    // Convert InputStream to String
    def payload = message.getBody(java.lang.String) as String;

    // Debugging: Log the payload (will only appear in trace/debug mode)
    def messageLog = messageLogFactory.getMessageLog(message);
    if (messageLog != null) {
        messageLog.addAttachmentAsString("Payload", payload, "text/plain");
    }

    // Parse the JSON payload
    def body;
    try {
        body = new JsonSlurper().parseText(payload);
    } catch (Exception e) {
        throw new RuntimeException("Failed to parse payload as JSON. Payload: " + payload, e);
    }

    // Extract dynamic values
    def id = body.id;
    def name = body.name;

    // Construct the SQL query dynamically
    def sqlQuery = "INSERT INTO \"USR_9TY5HSDNUYYS9FXX05BG3Y2ZO\".\"PRODUCT\" (ID, NAME) VALUES (${id}, '${name}');";

    // Set the SQL query as the message body
    message.setBody(sqlQuery);

    return message;
}
