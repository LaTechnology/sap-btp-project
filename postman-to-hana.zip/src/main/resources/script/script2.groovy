import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper;

// Main Script
Message processData(Message message) {
    // Parse the incoming JSON payload
    def body = new JsonSlurper().parseText(message.getBody(String));

    // Extract dynamic values
    def id = body.id;
    def name = body.name;

    // Construct the SQL query dynamically
    def sqlQuery = "INSERT INTO \"USR_9TY5HSDNUYYS9FXX05BG3Y2ZO\".\"PRODUCT\" (ID, NAME) VALUES (${id}, '${name}');";

    // Set the SQL query as the message body
    message.setBody(sqlQuery);

    return message;
}
